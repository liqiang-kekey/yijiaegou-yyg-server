/**
 * 变量压缩对应

 */

xbear = xb;
t = this;

