Component({
  /**
   * 组件的属性列表
   */
  properties: {
    comment: {
      type: String
    }
  }
})
