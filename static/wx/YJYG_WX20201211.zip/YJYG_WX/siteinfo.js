var siteinfo = { "siteroot": "https://yyg.yijiaegou.com/wxapp.php"}
module.exports = siteinfo